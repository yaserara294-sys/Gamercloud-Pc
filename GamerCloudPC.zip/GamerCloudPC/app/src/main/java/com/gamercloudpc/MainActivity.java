package com.gamercloudpc;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(12, 17, 29);
    private final int panel = Color.rgb(25, 34, 52);
    private final int cyan = Color.rgb(38, 208, 220);
    private LinearLayout content;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        getWindow().getDecorView().setSystemUiVisibility(0);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(28), dp(22), dp(28));
        scroll.addView(content);
        setContentView(scroll);

        TextView brand = text("GAMER CLOUD PC", 27, Color.WHITE, true);
        content.addView(brand);
        TextView subtitle = text("Tu centro de juegos en la nube", 14, cyan, false);
        content.addView(subtitle);
        spacer(24);

        cardTitle("TU BIBLIOTECA");
        LinearLayout game = card();
        TextView gameName = text("🚛  American Truck Simulator", 18, Color.WHITE, true);
        game.addView(gameName);
        TextView gameInfo = text("PC / Steam • Requiere un servidor con el juego instalado", 12,
                Color.LTGRAY, false);
        gameInfo.setPadding(0, dp(8), 0, dp(12));
        game.addView(gameInfo);
        Button connect = button("ABRIR MOONLIGHT");
        game.addView(connect);
        connect.setOnClickListener(v -> openMoonlight());
        content.addView(game);

        spacer(20);
        cardTitle("AJUSTES DE TRANSMISIÓN");
        LinearLayout settings = card();
        settings.addView(text("Resolución preferida: 1080p", 15, Color.WHITE, false));
        settings.addView(text("Velocidad preferida: 60 FPS", 15, Color.WHITE, false));
        TextView note = text("Estos son ajustes orientativos. Se configuran dentro de Moonlight cuando exista un PC servidor compatible.",
                12, Color.LTGRAY, false);
        note.setPadding(0, dp(10), 0, 0);
        settings.addView(note);
        content.addView(settings);

        spacer(20);
        cardTitle("ESTADO DEL SERVIDOR");
        LinearLayout status = card();
        status.addView(text("●  Aún no conectado", 16, Color.rgb(255, 190, 70), true));
        status.addView(text("Primero necesitamos una computadora Windows con GPU, Steam, ATS y Sunshine.",
                13, Color.LTGRAY, false));
        content.addView(status);

        spacer(18);
        Button help = button("¿CÓMO CONECTAR?");
        content.addView(help);
        help.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Conectar Gamer Cloud PC")
                .setMessage("1. Necesitas un PC servidor con Windows y una GPU compatible.\\n\\n" +
                        "2. Instala Sunshine en ese PC y añade American Truck Simulator.\\n\\n" +
                        "3. Instala Moonlight en este Redmi 15C.\\n\\n" +
                        "4. Empareja Moonlight con el PC usando el PIN que aparezca.\\n\\n" +
                        "Esta primera versión abre Moonlight; todavía no crea ni proporciona un servidor.")
                .setPositiveButton("Entendido", null).show());

        spacer(24);
        TextView footer = text("VERSIÓN 0.1.0 • PROYECTO PRIVADO", 11, Color.GRAY, false);
        footer.setGravity(Gravity.CENTER);
        content.addView(footer);
    }

    private void openMoonlight() {
        Intent launch = getPackageManager().getLaunchIntentForPackage("com.limelight");
        if (launch != null) {
            startActivity(launch);
        } else {
            new AlertDialog.Builder(this)
                    .setTitle("Moonlight no está instalado")
                    .setMessage("Instala Moonlight desde Google Play o su página oficial y vuelve a intentarlo.")
                    .setNegativeButton("Cerrar", null)
                    .setPositiveButton("Buscar Moonlight", (d, w) ->
                            startActivity(new Intent(Intent.ACTION_VIEW,
                                    Uri.parse("https://play.google.com/store/apps/details?id=com.limelight"))))
                    .show();
        }
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(16), dp(16), dp(16));
        box.setBackgroundColor(panel);
        return box;
    }
    private void cardTitle(String s) {
        TextView t = text(s, 12, cyan, true);
        t.setPadding(0, 0, 0, dp(10));
        content.addView(t);
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s); b.setTextColor(Color.BLACK);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(cyan));
        return b;
    }
    private void spacer(int h) {
        View v = new View(this);
        content.addView(v, new LinearLayout.LayoutParams(1, dp(h)));
    }
    private int dp(int n) {
        return (int)(n * getResources().getDisplayMetrics().density + 0.5f);
    }
}
