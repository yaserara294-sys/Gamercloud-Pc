# Gamer Cloud PC (prototipo 0.1.0)

Aplicación Android privada de inicio para Redmi 15C.

## Qué hace esta versión
- Muestra una biblioteca inicial con American Truck Simulator.
- Presenta preferencias orientativas de 1080p y 60 FPS.
- Abre Moonlight si está instalado; si no, ofrece su página de Google Play.
- Explica los pasos necesarios para conectar con un host Sunshine.

## Qué NO hace todavía
- No incluye una PC en la nube ni una GPU.
- No instala Steam ni American Truck Simulator.
- No configura automáticamente Moonlight ni empareja el servidor.
- No garantiza 1080p/60 FPS; depende del host, red y dispositivo.

## Compilar la APK
Abrir esta carpeta en Android Studio (JDK 17 y Android SDK 35) y ejecutar:
`gradle :app:assembleDebug`

La APK resultante estará en:
`app/build/outputs/apk/debug/app-debug.apk`

## Compilación en GitHub Actions
1. Crear un repositorio GitHub y subir el contenido de este proyecto.
2. Abrir la pestaña Actions.
3. Ejecutar "Build Gamer Cloud PC APK".
4. Descargar el artefacto `GamerCloudPC-debug-apk` cuando termine.
